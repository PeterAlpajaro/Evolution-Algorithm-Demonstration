	/*
	 * Project: ICS4UBackup
	 * Package: final_project
	 * Class:  Main
	 * Programmer: Peter Alpajaro
	 * Date Created: 5/26/2022
	 * Description: Main class. Creates the game manager to start the program
	 */


package final_project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main {

	public static void main(String[] args) {

		// Starts the game
		GameManager game = new GameManager();
		
		
	}

}
